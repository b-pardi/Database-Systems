--What are the smallest and largest account balances of a supplier?
SELECT MIN(s_acctbal), MAX(s_acctbal)
FROM supplier
